import re
import os
import logging
import aiohttp
import asyncio
import random
import time
from datetime import datetime
from telegram import Update, Bot, MessageEntity, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Updater, CommandHandler, CallbackContext, MessageHandler, Filters, CallbackQueryHandler
from bs4 import BeautifulSoup
from telegram.error import BadRequest, TimedOut, RetryAfter
from multiprocessing import Pool
import google.generativeai as genai

# Amazon API keys
AWS_STORE_ID = "couponsnexo0d-21"
AWS_ACCESS_KEY = "AKIAISDY7MQCWUVIQEMA"
AWS_SECRET_KEY = "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"

# Gemini AI key
GENAI_API_KEY = "AIzaSyATHYMLNVMOzd7mfFN98XJla4HOioIHEIk"
genai.configure(api_key=GENAI_API_KEY)

# Enable logging
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# Read environment variables
TOKEN = os.getenv('TOKEN')
DEV_CHAT_ID = os.getenv('DEV_CHAT_ID', None)
search_url = os.getenv('search_url', 'amazon.in')
affiliate_tag = os.getenv('affiliate_tag', AWS_STORE_ID)

# Handle the search_url and ensure that it's correct
if not search_url.startswith("amazon."):
    logger.error("Incorrect search URL. The URL must start with 'amazon.' followed by the country domain.")
if not search_url.endswith("/"):
    search_url += "/"
base_url = "https://www." + search_url

logger.info('Telegram bot started correctly with the affiliate_tag: %s', affiliate_tag)

bot = Bot(token=TOKEN)

user_agents = [
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3',
    'Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.9; rv:40.0) Gecko/20100101 Firefox/40.0',
    'Mozilla/5.0 (Macintosh; Intel Mac OS X 10.10; rv:40.0) Gecko/20100101 Firefox/40.0',
]

def create_affiliate_url(product_code: str) -> str:
    """Create a new URL with the product code and the affiliate tag."""
    return base_url + product_code + "?tag=" + affiliate_tag

def shorten_title(title: str, word_limit=12) -> str:
    """Shorten the title if it exceeds the word limit."""
    words = title.split()
    if len(words) > word_limit:
        return ' '.join(words[:word_limit]) + '...'
    return title

async def fetch_search_results(session, search_url, headers):
    async with session.get(search_url, headers=headers) as response:
        response.raise_for_status()
        content = await response.text()
        return content

async def search_amazon(session: aiohttp.ClientSession, keyword: str, exclude_list: list = []) -> list:
    headers = {
        'User-Agent': random.choice(user_agents),
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'gzip, deflate, br',
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Connection': 'keep-alive'
    }
    search_url = f"{base_url}s?k={keyword.replace(' ', '+')}"
    logger.info("Searching Amazon for keyword: %s", keyword)

    content = await fetch_search_results(session, search_url, headers)
    soup = BeautifulSoup(content, 'html.parser')

    products = []
    product_items = soup.find_all('div', {'data-component-type': 's-search-result'})
    logger.info("Found %d products for the keyword '%s'", len(product_items), keyword)

    for item in product_items:
        title_tag = item.find('span', {'class': 'a-size-medium a-color-base a-text-normal'})
        if not title_tag:
            title_tag = item.find('a', {'class': 'a-link-normal a-text-normal'})  # Fallback if first approach fails
        if not title_tag:
            title_tag = item.find('h2')  # Titles sometimes appear under <h2> tags

        if title_tag:
            title = shorten_title(title_tag.text.strip())
            if title in exclude_list:
                continue
            link_tag = item.find('a', {'class': 'a-link-normal s-no-outline'})
            if link_tag and 'href' in link_tag.attrs:
                link = "https://www.amazon.in" + link_tag['href']
                product_code = re.search(r'dp/[\w]+|gp/product/[\w]+|gp/aw/d/[\w]+', link)
                if product_code:
                    product_code = product_code.group(0)
                    current_price_tag = item.find('span', {'class': 'a-price-whole'})
                    current_price_fraction = item.find('span', {'class': 'a-price-fraction'})
                    if current_price_tag:
                        current_price = f"{current_price_tag.text.strip()}"
                        if current_price_fraction:
                            current_price += f".{current_price_fraction.text.strip()}"
                        try:
                            current_price_formatted = f"₹{float(current_price.replace(',', '')):,} ✅"
                        except ValueError:
                            current_price_formatted = "N/A"
                    else:
                        current_price_formatted = "N/A"

                    rating_tag = item.find('span', {'class': 'a-icon-alt'})
                    purchase_tag = item.find('span', {'class': 'a-size-base'})
                    delivery_info = item.find('span', {'class': 'a-color-base a-text-bold'})
                    description_tag = item.find('span', {'class': 'a-size-base-plus a-color-base a-text-normal'})

                    rating = rating_tag.text.strip() if rating_tag else "No rating"
                    purchases = purchase_tag.text.strip() if purchase_tag else "No purchases"
                    delivery = delivery_info.text.strip() if delivery_info else "No delivery info"
                    description = description_tag.text.strip() if description_tag else "No description available"

                    status = f"Rating: {rating}, Purchases: {purchases}"

                    affiliate_link = create_affiliate_url(product_code)
                    products.append((title, current_price_formatted, affiliate_link, status, description, delivery, product_code))
                    logger.info("Product appended: %s", title)
                else:
                    logger.warning("Product code not found for link: %s", link)
            else:
                logger.warning("Link tag missing href or not found for item: %s", item)
        else:
            logger.warning("Title tag not found for item: %s", item)

        if len(products) >= 20:
            break  # Limit to 20 products

    logger.info("Total products appended: %d", len(products))
    return products


async def fetch_product_details(session, url):
    async with session.get(url) as response:
        response.raise_for_status()
        content = await response.text()
        soup = BeautifulSoup(content, 'html.parser')
        specs = soup.find('div', {'id': 'prodDetails'}).text.strip()
        description = soup.find('div', {'id': 'feature-bullets'}).text.strip()
        return {'specs': specs, 'description': description}

def handle_search_requests(keywords: list):
    with Pool(processes=4) as pool:  # Adjust the number of processes as needed
        results = pool.map(search_amazon_multiprocessing, keywords)
    return results

def search_amazon_multiprocessing(keyword: str) -> list:
    async def fetch_products():
        async with aiohttp.ClientSession() as session:
            products = await search_amazon(session, keyword)
            return products

    return asyncio.run(fetch_products())

def format_product_message(products: list) -> list:
    """Format the product information for the Telegram message."""
    if not products:
        logger.info("No related products found.")
        return [("No related products found.", None)]

    response_list = []
    for title, current_price, link, status, description, delivery, product_code in products:
        buttons = [
            [InlineKeyboardButton("Buy Now", url=link), InlineKeyboardButton("More", callback_data=f'more_{product_code}')]
        ]
        keyboard = InlineKeyboardMarkup(buttons)
        message = (
            f"🌐 Amazon Link: [Amazon]({link})\n\n"
            f"🛒 {title}\n\n"
            f"🏷️ {current_price}\n\n"
            f"📊 Status: {status}\n\n"
        )
        logger.info("Formatted product: %s", title)
        response_list.append((message, keyboard))
    return response_list

def send_split_messages(bot: Bot, chat_id: int, messages: list) -> None:
    """Send split messages to avoid Telegram's message length limit."""
    max_message_length = 4096
    for message, keyboard in messages:
        while len(message) > max_message_length:
            split_index = message[:max_message_length].rfind('\n\n')
            if split_index == -1:
                split_index = max_message_length
            try:
                bot.send_message(chat_id=chat_id, text=message[:split_index], parse_mode='Markdown')
            except BadRequest as e:
                logger.error("Failed to send message: %s", e)
                return  # Exit the function if we can't send the message
            message = message[split_index:]
        while True:
            try:
                bot.send_message(chat_id=chat_id, text=message, parse_mode='Markdown', reply_markup=keyboard)
                break  # Exit the loop if the message is sent successfully
            except BadRequest as e:
                logger.error("Failed to send message: %s", e)
                return  # Exit the function if we can't send the message
            except TimedOut as e:
                logger.error("Message sending timed out: %s", e)
                time.sleep(2)  # Wait before retrying
            except RetryAfter as e:
                logger.error("Flood control exceeded. Retry after %s seconds.", e.retry_after)
                time.sleep(e.retry_after)  # Wait for the required time before retrying

def start(update: Update, context: CallbackContext) -> None:
    """Send a message when the command /start is issued."""
    update.message.reply_text(
        'Hello! This bot helps you find products on Amazon with ease. If you purchase using our links, we earn a small commission (1% to 4%). '
        'We donate 70% of the earnings to charity and use 30% to maintain and improve this bot. Thank you for supporting us!'
    )

user_searches = {}  # To keep track of user searches and the products shown

async def handle_text_message(update: Update, context: CallbackContext) -> None:
    """Handle regular text messages sent by the user."""
    chat_id = update.message.chat_id
    msg = update.message.text.strip()
    logger.info('Received text message in chat ID: %s', chat_id)

    # Check for Amazon links and convert them to affiliate links
    amazon_patterns = [r'amazon(\.[a-z]{2,3}){1,2}\/(?:[^\s\n]*)?', r'amaz\.(to|com)']
    for pattern in amazon_patterns:
        matches = re.findall(pattern, msg)
        if matches:
            for match in matches:
                start_index = msg.lower().find(match)
                m = re.search(r'dp/[\w]+|gp/product/[\w]+|gp/aw/d/[\w]+', msg[start_index:])
                p_code = m.group(0) if m else ""
                new_url = create_affiliate_url(p_code)
                msg = msg.replace(match, new_url)
        update.message.reply_text(msg)
    else:
        update.message.reply_text("Received your message!")

async def handle_message(update: Update, context: CallbackContext) -> None:
    """Handle the message sent by the user."""
    if update.message:
        chat_id = update.message.chat_id
        msg = update.message.text.strip()
        logger.info('Received message in chat ID: %s', chat_id)

        if msg.startswith("/"):
            update.message.reply_text("Command execution is disabled.")
        else:
            await handle_text_message(update, context)
        
        # Update current keyword
        context.user_data['current_keyword'] = msg
        current_keyword = context.user_data['current_keyword']
        shown_products = user_searches.get(chat_id, {}).get(current_keyword, [])
        
        async with aiohttp.ClientSession() as session:
            products = await search_amazon(session, current_keyword, [])
            logger.info('Products to be formatted: %s', products)
            product_messages = format_product_message(products)
            
            shown_titles = [title for (title, _, _, _, _, _, _) in products]
            user_searches[chat_id] = user_searches.get(chat_id, {})
            user_searches[chat_id][current_keyword] = shown_titles
            
            for message, keyboard in product_messages:
                send_split_messages(context.bot, chat_id, [(message, keyboard)])
                
            if len(product_messages) == 20:
                context.bot.send_message(chat_id=chat_id, text="Click below to see more products.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("More", callback_data="more_products")]]))

async def more_products(update: Update, context: CallbackContext) -> None:
    """Handle the 'More Products' button callback."""
    query = update.callback_query
    query.answer()
    
    chat_id = query.message.chat.id
    current_keyword = context.user_data.get('current_keyword')
    shown_products = user_searches.get(chat_id, {}).get(current_keyword, [])
    
    async with aiohttp.ClientSession() as session:
        products = await search_amazon(session, current_keyword, shown_products)
        logger.info('More products to be formatted: %s', products)
        product_messages = format_product_message(products)
        
        shown_titles = [title for (title, _, _, _, _, _, _) in products]
        user_searches[chat_id][current_keyword] += shown_titles
        
        for message, keyboard in product_messages:
            send_split_messages(context.bot, chat_id, [(message, keyboard)])
        
        if len(product_messages) == 20:
            context.bot.send_message(chat_id=chat_id, text="Click below to see more products.", reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("More", callback_data="more_products")]]))


# Adding the missing more_info function
async def more_info(update: Update, context: CallbackContext) -> None:
    """Handle the 'more' button callback."""
    query = update.callback_query
    query.answer()
    
    product_code = query.data.split('_')[1]
    delivery_info = "Free delivery on eligible orders."  # Example delivery info
    
    buttons = [
        [InlineKeyboardButton("Product Details", callback_data=f'details_{product_code}'), InlineKeyboardButton("Description", callback_data=f'desc_{product_code}')],
        [InlineKeyboardButton("About This Bot", callback_data='about_bot')],
        [InlineKeyboardButton("Back", callback_data=f'back_{product_code}'), InlineKeyboardButton("Buy Now", url=create_affiliate_url(product_code))]
    ]
    keyboard = InlineKeyboardMarkup(buttons)
    
    updated_text = f"{query.message.text}\n\n🚚 {delivery_info}"
    
    await query.edit_message_text(text=updated_text, parse_mode='Markdown', reply_markup=keyboard)

async def product_specs(update: Update, context: CallbackContext) -> None:
    """Handle the 'Product Details' button callback."""
    query = update.callback_query
    query.answer()
    
    product_code = query.data.split('_')[1]
    async with aiohttp.ClientSession() as session:
        product_details = await fetch_product_details(session, create_affiliate_url(product_code))
        specs = product_details['specs']
    
    buttons = [
        [InlineKeyboardButton("Back", callback_data=f'more_{product_code}'), InlineKeyboardButton("Buy Now", url=create_affiliate_url(product_code))]
    ]
    keyboard = InlineKeyboardMarkup(buttons)
    
    updated_text = f"🔍 **Product Details**:\n{specs}"
    
    await query.edit_message_text(text=updated_text, parse_mode='Markdown', reply_markup=keyboard)

async def product_description(update: Update, context: CallbackContext) -> None:
    """Handle the 'Description' button callback."""
    query= update.callback_query
    query.answer()
    
    product_code = query.data.split('_')[1]
    async with aiohttp.ClientSession() as session:
        product_details = await fetch_product_details(session, create_affiliate_url(product_code))
        description = product_details['description']
    
    buttons = [
        [InlineKeyboardButton("Back", callback_data=f'more_{product_code}'), InlineKeyboardButton("Buy Now", url=create_affiliate_url(product_code))]
    ]
    keyboard = InlineKeyboardMarkup(buttons)
    
    updated_text = f"📄 **Product Description**:\n{description}"
    
    await query.edit_message_text(text=updated_text, parse_mode='Markdown', reply_markup=keyboard)

async def fetch_product_details(session, url):
    async with session.get(url) as response:
        response.raise_for_status()
        content = await response.text()
        soup = BeautifulSoup(content, 'html.parser')
        specs  = soup.find('div', {'id': 'prodDetails'}).text.strip()
        description = soup.find('div', {'id': 'feature-bullets'}).text.strip()
        return {'specs': specs, 'description': description}

def main():
    """Start the bot."""
    # Create the Updater and pass it your bot's token.
    updater = Updater(TOKEN, use_context=True)
    dispatcher = updater.dispatcher

    # Start command handler
    dispatcher.add_handler(CommandHandler("start", start))
    
    # Text message handler for simple text queries
    dispatcher.add_handler(MessageHandler(Filters.text & (~Filters.entity(MessageEntity.URL)), lambda update, context: asyncio.run(handle_message(update, context))))

    # Callback query handlers
    dispatcher.add_handler(CallbackQueryHandler(lambda update, context: asyncio.run(more_products(update, context)), pattern='more_products'))
    dispatcher.add_handler(CallbackQueryHandler(lambda update, context: asyncio.run(more_info(update, context)), pattern='more_'))
    dispatcher.add_handler(CallbackQueryHandler(lambda update, context: asyncio.run(product_specs(update, context)), pattern='details_'))
    dispatcher.add_handler(CallbackQueryHandler(lambda update, context: asyncio.run(product_description(update, context)), pattern='desc_'))

    # Start the bot
    updater.start_polling()
    updater.idle()

if __name__ == '__main__':
    main()
